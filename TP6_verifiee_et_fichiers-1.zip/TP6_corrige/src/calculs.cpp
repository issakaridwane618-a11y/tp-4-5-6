#include "calculs.hpp"
#include <cmath>
#include <stdexcept>

namespace uin {
    double moyenne(std::span<const double> notes) {
        if (notes.empty()) throw std::invalid_argument("Impossible de calculer la moyenne d'un tableau vide");
        double somme = 0.0;
        for (double note : notes) somme += note;
        return somme / static_cast<double>(notes.size());
    }

    double arrondir(double valeur, int decimales) {
        const double facteur = std::pow(10.0, decimales);
        return std::round(valeur * facteur) / facteur;
    }
}
