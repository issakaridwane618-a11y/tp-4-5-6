#include "calculs.hpp"
#include "regles.hpp"
#include <array>
#include <iostream>

int main() {
    const std::array notes{12.0, 15.0, 9.0};
    const double m = uin::moyenne(notes);
    std::cout << "Moyenne : " << uin::arrondir(m, 2) << '\n';
    std::cout << "Mention : " << uin::libelle(uin::mentionPour(m)) << '\n';
}
