#include <iostream>
import uin.regles;

int main() {
    const double moyenne = 14.5;
    std::cout << uin::libelle(uin::mentionPour(moyenne)) << '\n';
}
