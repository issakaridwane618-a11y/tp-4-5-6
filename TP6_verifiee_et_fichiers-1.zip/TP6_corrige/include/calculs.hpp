#pragma once
#include <span>

namespace uin {
    double moyenne(std::span<const double> notes);
    double arrondir(double valeur, int decimales);
}
