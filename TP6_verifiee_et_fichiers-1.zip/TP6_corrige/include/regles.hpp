#pragma once
#include <string_view>

namespace uin {
    enum class Mention { Ajourne, Passable, AssezBien, Bien, TresBien };
    Mention mentionPour(double moyenne);
    std::string_view libelle(Mention mention);
}
