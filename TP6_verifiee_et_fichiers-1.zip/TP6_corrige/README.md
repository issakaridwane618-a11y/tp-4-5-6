# TP 6 — Bibliothèques et modules (correction testée)

## Partie A — Bibliothèques (Linux)

À partir de la racine `TP6_corrige` :

### Bibliothèque statique
```bash
cd build_static
g++ -std=c++23 -I../include -c ../src/calculs.cpp -o calculs.o
g++ -std=c++23 -I../include -c ../src/regles.cpp -o regles.o
ar rcs libuincalculs.a calculs.o regles.o
g++ -std=c++23 -I../include ../app/main.cpp -L. -luincalculs -o bulletin_static
./bulletin_static
```

### Bibliothèque dynamique
```bash
cd ../build_shared
g++ -std=c++23 -I../include -fPIC -c ../src/calculs.cpp -o calculs.o
g++ -std=c++23 -I../include -fPIC -c ../src/regles.cpp -o regles.o
g++ -shared calculs.o regles.o -o libuincalculs.so
g++ -std=c++23 -I../include ../app/main.cpp -L. -luincalculs -o bulletin_shared
LD_LIBRARY_PATH=. ./bulletin_shared
```

Pour lancer sans `LD_LIBRARY_PATH`, le système ne trouve pas la bibliothèque locale (`libuincalculs.so => not found`). Pour tester explicitement :
```bash
./bulletin_shared
```
Cela devrait échouer tant que la bibliothèque n'est pas dans un chemin de recherche standard ou que le chemin de chargement n'est pas fourni.

### Comparer les tailles et inspecter
```bash
ls -l bulletin_static bulletin_shared
nm -C calculs.o
nm calculs.o | grep arrondir
echo 'COLLER_ICI_LE_NOM_DECORÉ' | c++filt
ldd ./bulletin_shared
```
Les symboles `T` sont définis dans le fichier objet; les symboles `U` sont utilisés mais résolus ailleurs (ex. `std::pow` vient de la bibliothèque mathématique). Pour `arrondir`, `nm calculs.o | grep arrondir` donne son nom décoré; collez-le dans `c++filt`.

## Partie B — Modules C++20

Les fichiers `modules/regles.cppm`, `modules/regles_impl.cpp`, `modules/main.cpp` et `modules/CMakeLists.txt` suivent le modèle du cours.

```bash
cd modules
cmake -S . -B build -G Ninja
cmake --build build
./build/demo
```
Sortie attendue : `Bien`.

### Expériences demandées
1. Le programme affiche `Bien`.
2. Dans `regles.cppm`, enlever `export` devant `namespace uin` : les déclarations du namespace ne sont plus exportées; `main.cpp` ne peut plus appeler `uin::libelle` / `uin::mentionPour` et la compilation échoue.
3. Ajouter une fonction non exportée dans l'interface puis tenter de l'appeler depuis `main.cpp` : appel impossible depuis l'importateur, car la fonction n'est pas exportée.
4. Définir `#define SEUIL 10` dans le fragment global (`module;`) : la macro ne devient pas visible dans `main.cpp` qui importe le module.
5. `import std;` n'a pas été essayé ici; la prise en charge varie selon le compilateur et sa version. Dans l'environnement testé (GCC 14.2), les modules nommés sont pris en charge via CMake/Ninja, mais `import std;` n'est pas une hypothèse à faire.

## Résultats de vérification
- Partie A statique : compilation et exécution réussies; affichage `Moyenne : 12` et `Mention : Assez bien`.
- Partie A dynamique : compilation et exécution réussies avec `LD_LIBRARY_PATH=.`; même affichage.
- Partie B : configuration CMake, build Ninja et exécution réussis; affichage `Bien`.
- Inspection `nm` : fonctions `uin::moyenne` et `uin::arrondir` sont des symboles `T`; des fonctions de bibliothèque comme `pow` sont des symboles `U` dans l'objet, à résoudre au lien.
